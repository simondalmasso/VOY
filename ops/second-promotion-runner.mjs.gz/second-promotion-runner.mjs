#!/usr/bin/env node
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync, readdirSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';

const env = process.env;
const repo = env.GITHUB_REPOSITORY || 'simonkey888/VOY';
const evidenceDir = resolve(env.EVIDENCE_DIR || 'evidence');
const sourceRoot = resolve(env.SOURCE_ROOT || 'source');
const workerName = env.WORKER_NAME || 'voy-app';
const workerUrl = env.WORKER_URL || 'https://voy-app.simondalmasso44.workers.dev';
const expectedHead = required('EXPECTED_PR_HEAD');
const expectedShort = required('EXPECTED_BUILD_HASH');
const stableVersionId = required('STABLE_VERSION_ID');
const candidateVersionId = required('CANDIDATE_VERSION_ID');
const expectedDeploymentId = required('EXPECTED_DEPLOYMENT_ID');
const expectedCiRun = Number(required('EXPECTED_CI_RUN'));
const expectedCandidateRun = Number(required('EXPECTED_CANDIDATE_RUN'));
const candidateArtifactId = Number(required('CANDIDATE_ARTIFACT_ID'));
const candidateArtifactDigest = required('CANDIDATE_ARTIFACT_DIGEST');
const githubToken = required('GITHUB_TOKEN');
const cfAccountId = required('CLOUDFLARE_ACCOUNT_ID');
const cfToken = required('CLOUDFLARE_API_TOKEN');
const expectedProductionVersion = env.EXPECTED_PRODUCTION_VERSION || 'V7.8.0';
const expectedStableBuild = env.EXPECTED_STABLE_BUILD || '4a8b91e';
const requiredPaths = [
  '/', '/VOY-Lite.html', '/core/cityPlatform.js?v=1',
  '/cities/_default/profile.json', '/cities/_default/providers.json', '/cities/_default/transport.json', '/cities/_default/fares.json', '/cities/_default/feature_flags.json',
  '/cities/santa-fe/profile.json', '/cities/santa-fe/providers.json', '/cities/santa-fe/transport.json', '/cities/santa-fe/fares.json', '/cities/santa-fe/feature_flags.json'
];

mkdirSync(evidenceDir, { recursive: true });

function required(name) {
  const value = env[name];
  if (!value) throw new Error(`missing_environment:${name}`);
  return value;
}

function writeJson(name, value) {
  writeFileSync(join(evidenceDir, name), `${JSON.stringify(value, null, 2)}\n`);
}

function appendGithubEnv(name, value) {
  if (env.GITHUB_ENV) appendFileSync(env.GITHUB_ENV, `${name}=${value}\n`);
}

function sha256(buffer) {
  return createHash('sha256').update(buffer).digest('hex');
}

async function fetchWithTimeout(url, options = {}, timeout = 30_000) {
  return fetch(url, { ...options, signal: AbortSignal.timeout(timeout) });
}

async function jsonRequest(url, options = {}, timeout = 30_000) {
  const response = await fetchWithTimeout(url, options, timeout);
  const text = await response.text();
  let body;
  try { body = JSON.parse(text); } catch { throw new Error(`invalid_json_response:${response.status}:${url}:${text.slice(0, 200)}`); }
  if (!response.ok) throw new Error(`http_${response.status}:${url}:${JSON.stringify(body).slice(0, 300)}`);
  return body;
}

function githubHeaders() {
  return { Authorization: `Bearer ${githubToken}`, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' };
}

function cfHeaders() {
  return { Authorization: `Bearer ${cfToken}`, 'Content-Type': 'application/json' };
}

async function github(path) {
  return jsonRequest(`https://api.github.com/repos/${repo}${path}`, { headers: githubHeaders(), redirect: 'follow' });
}

async function cloudflare(path) {
  const payload = await jsonRequest(`https://api.cloudflare.com/client/v4/accounts/${cfAccountId}/workers/scripts/${workerName}${path}`, { headers: cfHeaders(), redirect: 'follow' });
  if (payload.success !== true) throw new Error(`cloudflare_api_failed:${path}:${JSON.stringify(payload.errors || payload)}`);
  return payload;
}

function deploymentList(payload) {
  const list = payload.result?.deployments || payload.result;
  if (!Array.isArray(list)) throw new Error('deployments_shape_unknown');
  return list;
}

function inspectDeployment(payload, expectedStableTraffic, expectedCandidateTraffic, expectedId = null) {
  const active = deploymentList(payload)[0];
  if (!active || !Array.isArray(active.versions)) throw new Error('active_deployment_missing');
  const byId = new Map(active.versions.map(v => [v.version_id, Number(v.percentage)]));
  const valid = active.versions.length === 2 && byId.get(stableVersionId) === expectedStableTraffic && byId.get(candidateVersionId) === expectedCandidateTraffic && (!expectedId || active.id === expectedId);
  return { active, byId, valid, stableTraffic: byId.get(stableVersionId), candidateTraffic: byId.get(candidateVersionId) };
}

function bindingContract(payload) {
  const bindings = payload.result?.resources?.bindings;
  if (!Array.isArray(bindings)) throw new Error('version_bindings_missing');
  return bindings.map(binding => `${binding.name}:${binding.type}`).sort();
}

async function normalHealth(label) {
  const probe = `${label}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const response = await fetchWithTimeout(`${workerUrl}/api/health?${encodeURIComponent(label)}=${probe}`, {
    redirect: 'manual',
    headers: { Accept: 'application/json', 'Cache-Control': 'no-cache, no-store, max-age=0', Pragma: 'no-cache' }
  }, 20_000);
  if (response.status !== 200) throw new Error(`health_http_${response.status}`);
  const body = await response.json();
  return { body, headers: Object.fromEntries(response.headers.entries()), url: response.url };
}

async function getPrWithMergeability() {
  let last;
  for (let attempt = 1; attempt <= 8; attempt += 1) {
    last = await github('/pulls/21');
    if (last.mergeable !== null) return last;
    await new Promise(resolvePromise => setTimeout(resolvePromise, 1500));
  }
  return last;
}

async function downloadCandidateArtifact() {
  const metadata = await github(`/actions/artifacts/${candidateArtifactId}`);
  if (metadata.expired) throw new Error('candidate_artifact_expired');
  if (metadata.digest !== candidateArtifactDigest) throw new Error(`candidate_artifact_digest_changed:${metadata.digest}`);
  if (metadata.workflow_run?.head_sha !== expectedHead) throw new Error(`candidate_artifact_head_changed:${metadata.workflow_run?.head_sha}`);
  const response = await fetchWithTimeout(`https://api.github.com/repos/${repo}/actions/artifacts/${candidateArtifactId}/zip`, { headers: githubHeaders(), redirect: 'follow' }, 60_000);
  if (!response.ok) throw new Error(`artifact_download_http_${response.status}`);
  const zip = Buffer.from(await response.arrayBuffer());
  const zipPath = join(evidenceDir, 'candidate-artifact.zip');
  const extractDir = join(evidenceDir, 'candidate-artifact');
  writeFileSync(zipPath, zip);
  mkdirSync(extractDir, { recursive: true });
  execFileSync('unzip', ['-q', '-o', zipPath, '-d', extractDir], { stdio: 'inherit' });
  const base = join(extractDir, 'test-results', 'exact-final-candidate');
  const version = JSON.parse(readFileSync(join(base, 'candidate-version.json'), 'utf8'));
  const manifest = JSON.parse(readFileSync(join(base, 'materialized-required-assets.json'), 'utf8'));
  if (version.version_id !== candidateVersionId || version.source_sha !== expectedHead) throw new Error('candidate_artifact_version_mapping_failed');
  if (!Array.isArray(manifest) || manifest.length !== 13) throw new Error(`candidate_artifact_manifest_count:${manifest?.length}`);
  const paths = manifest.map(asset => asset.path);
  if (JSON.stringify(paths) !== JSON.stringify(requiredPaths)) throw new Error(`candidate_artifact_paths_changed:${JSON.stringify(paths)}`);
  writeJson('candidate-artifact-metadata.json', metadata);
  writeJson('expected-materialized-assets.json', manifest);
  return { metadata, version, manifest };
}

async function preflight() {
  const sourceSha = execFileSync('git', ['-C', sourceRoot, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  if (sourceSha !== expectedHead) throw new Error(`source_head_changed:${sourceSha}`);
  const pr = await getPrWithMergeability();
  if (pr.state !== 'open' || pr.draft !== true || pr.mergeable !== true || pr.head?.sha !== expectedHead || pr.merged === true) {
    throw new Error(`pr_preflight_failed:${JSON.stringify({ state: pr.state, draft: pr.draft, mergeable: pr.mergeable, head: pr.head?.sha, merged: pr.merged })}`);
  }
  const [ciRun, candidateRun, deployments, stableDetail, candidateDetail, health, artifact] = await Promise.all([
    github(`/actions/runs/${expectedCiRun}`),
    github(`/actions/runs/${expectedCandidateRun}`),
    cloudflare('/deployments'),
    cloudflare(`/versions/${stableVersionId}`),
    cloudflare(`/versions/${candidateVersionId}`),
    normalHealth('second_promotion_preflight'),
    downloadCandidateArtifact()
  ]);
  for (const [name, run] of [['ci', ciRun], ['candidate', candidateRun]]) {
    if (run.status !== 'completed' || run.conclusion !== 'success' || run.head_sha !== expectedHead) {
      throw new Error(`${name}_run_changed:${JSON.stringify({ id: run.id, status: run.status, conclusion: run.conclusion, head_sha: run.head_sha })}`);
    }
  }
  const deployment = inspectDeployment(deployments, 100, 0, expectedDeploymentId);
  if (!deployment.valid) throw new Error(`deployment_preflight_changed:${JSON.stringify({ id: deployment.active?.id, stable: deployment.stableTraffic, candidate: deployment.candidateTraffic, count: deployment.active?.versions?.length })}`);
  const stableBindings = bindingContract(stableDetail);
  const candidateBindings = bindingContract(candidateDetail);
  if (stableBindings.length !== 13 || candidateBindings.length !== 13 || JSON.stringify(stableBindings) !== JSON.stringify(candidateBindings)) throw new Error('binding_contract_changed');
  for (const requiredBinding of ['ASSETS', 'VOY_METRICS', 'NOMINATIM_COORDINATOR']) {
    if (!candidateBindings.some(value => value.startsWith(`${requiredBinding}:`))) throw new Error(`required_binding_missing:${requiredBinding}`);
  }
  if (health.body?.ok !== true || health.body?.version !== expectedProductionVersion || health.body?.build_hash !== expectedStableBuild) {
    throw new Error(`production_health_changed:${JSON.stringify(health.body)}`);
  }
  const snapshot = {
    timestamp: new Date().toISOString(),
    pr: { state: pr.state, draft: pr.draft, mergeable: pr.mergeable, head_sha: pr.head.sha, merged: pr.merged },
    runs: { ci: { id: ciRun.id, conclusion: ciRun.conclusion, head_sha: ciRun.head_sha }, candidate: { id: candidateRun.id, conclusion: candidateRun.conclusion, head_sha: candidateRun.head_sha } },
    deployment: { id: deployment.active.id, stable_version_id: stableVersionId, stable_traffic: 100, candidate_version_id: candidateVersionId, candidate_traffic: 0 },
    health: health.body,
    binding_count: candidateBindings.length,
    bindings: candidateBindings,
    rollback_target: stableVersionId,
    required_assets: artifact.manifest.length,
    candidate_artifact_id: candidateArtifactId,
    candidate_artifact_digest: candidateArtifactDigest
  };
  writeJson('preflight.json', snapshot);
  appendGithubEnv('PREFLIGHT_PASS', '1');
  console.log(JSON.stringify(snapshot, null, 2));
}

function assetHeaders(response) {
  const headers = Object.fromEntries(response.headers.entries());
  const ray = headers['cf-ray'] || null;
  const colo = ray && ray.includes('-') ? ray.split('-').at(-1) : null;
  return {
    content_type: headers['content-type'] || null,
    content_length: headers['content-length'] || null,
    etag: headers.etag || null,
    age: headers.age || null,
    cache_status: headers['cf-cache-status'] || null,
    cf_ray: ray,
    colo
  };
}

async function probeAsset(contract, asset, expected, round, index) {
  const separator = asset.path.includes('?') ? '&' : '?';
  const stamp = `${Date.now()}-${round}-${index}-${Math.random().toString(16).slice(2)}`;
  const requestedUrl = `${workerUrl}${asset.path}${separator}production_asset_probe=${stamp}`;
  try {
    const response = await fetchWithTimeout(requestedUrl, {
      redirect: 'manual',
      headers: { Accept: '*/*', 'Cache-Control': 'no-cache, no-store, max-age=0', Pragma: 'no-cache' }
    }, 20_000);
    const body = Buffer.from(await response.arrayBuffer());
    const evaluated = contract.evaluateRemoteAsset(asset, body, {
      timestamp: new Date().toISOString(),
      round,
      requested_url: requestedUrl,
      effective_url: response.url,
      status: response.status,
      ...assetHeaders(response),
      version_id: candidateVersionId,
      redirects: response.status >= 300 && response.status < 400 ? 1 : 0
    }, expected);
    if (evaluated.effective_url !== requestedUrl) evaluated.pass = false;
    return evaluated;
  } catch (error) {
    return {
      timestamp: new Date().toISOString(), round, path: asset.path, requested_url: requestedUrl, effective_url: null,
      status: 0, body_bytes: 0, expected_source_sha256: expected.expectedSha256, body_sha256: sha256(Buffer.alloc(0)),
      hash_pass: false, schema_result: false, city_id: null, pass: false, error: String(error?.stack || error), version_id: candidateVersionId
    };
  }
}

function loadExpectedManifest() {
  const path = join(evidenceDir, 'expected-materialized-assets.json');
  if (!existsSync(path)) throw new Error('expected_materialized_assets_missing');
  return JSON.parse(readFileSync(path, 'utf8'));
}

async function singleProductionRound(contract, expectedManifest, round) {
  const startedAt = Date.now();
  const [deployments, health, assets] = await Promise.all([
    cloudflare('/deployments'),
    normalHealth(`production_convergence_${round}`),
    Promise.all(contract.REQUIRED_CITY_PLATFORM_ASSETS.map((asset, index) => probeAsset(contract, asset, expectedManifest[index], round, index)))
  ]);
  const deployment = inspectDeployment(deployments, 0, 100);
  const healthPass = health.body?.ok === true && health.body?.version === expectedProductionVersion && health.body?.build_hash === expectedShort;
  const assetsPass = assets.length === 13 && assets.every(asset => asset.pass === true && asset.status === 200 && asset.body_bytes > 0 && asset.hash_pass === true && asset.schema_result === true && (asset.city_id === null || asset.city_pass === true) && asset.redirects === 0);
  return {
    record: {
      timestamp: new Date().toISOString(), round, elapsed_round_ms: Date.now() - startedAt,
      deployment_id: deployment.active?.id || null, deployment_pass: deployment.valid,
      stable_traffic: deployment.stableTraffic, candidate_traffic: deployment.candidateTraffic,
      health_pass: healthPass, health: health.body,
      required_assets: assets.length, passed_assets: assets.filter(asset => asset.pass).length,
      body_hash_pass: assets.filter(asset => asset.hash_pass).length,
      schema_pass: assets.filter(asset => asset.schema_result).length,
      assets_pass: assetsPass,
      pass: deployment.valid && healthPass && assetsPass
    },
    assets,
    deployments
  };
}

async function converge() {
  const contract = await import(new URL(`file://${join(sourceRoot, 'scripts', 'required-city-platform-assets.mjs')}`).href);
  contract.assertCanonicalAssetSet();
  const expectedManifest = loadExpectedManifest();
  if (expectedManifest.length !== 13) throw new Error('expected_manifest_not_13');
  const logPath = join(evidenceDir, 'production-convergence.jsonl');
  const assetsLogPath = join(evidenceDir, 'production-convergence-assets.jsonl');
  writeFileSync(logPath, '');
  writeFileSync(assetsLogPath, '');
  let consecutive = 0;
  let streakStartedAt = null;
  let final = null;
  const intervalMs = Number(env.CONVERGENCE_INTERVAL_MS || 7000);
  for (let round = 1; round <= 120; round += 1) {
    let result;
    try {
      result = await singleProductionRound(contract, expectedManifest, round);
    } catch (error) {
      result = { record: { timestamp: new Date().toISOString(), round, pass: false, error: String(error?.stack || error) }, assets: [] };
    }
    if (result.record.pass) {
      consecutive += 1;
      if (streakStartedAt === null) streakStartedAt = Date.now();
    } else {
      consecutive = 0;
      streakStartedAt = null;
    }
    const stableWindowMs = streakStartedAt === null ? 0 : Date.now() - streakStartedAt;
    result.record.consecutive = consecutive;
    result.record.stable_window_ms = stableWindowMs;
    appendFileSync(logPath, `${JSON.stringify(result.record)}\n`);
    for (const asset of result.assets) appendFileSync(assetsLogPath, `${JSON.stringify(asset)}\n`);
    console.log(JSON.stringify(result.record));
    if (consecutive >= 20 && stableWindowMs >= 120_000) {
      final = { ...result.record, required_consecutive: 20, minimum_window_ms: 120000 };
      writeJson('production-convergence-proof.json', final);
      writeJson('production-assets-final.json', result.assets);
      writeJson('production-deployments-converged.json', result.deployments);
      appendGithubEnv('PRODUCTION_DEPLOYMENT_ID', result.record.deployment_id);
      break;
    }
    await new Promise(resolvePromise => setTimeout(resolvePromise, intervalMs));
  }
  if (!final) throw new Error('production_did_not_reach_reinforced_convergence');
  return final;
}

function collectJsonFiles(root, predicate, acc = []) {
  if (!existsSync(root)) return acc;
  for (const entry of readdirSync(root)) {
    const path = join(root, entry);
    const stat = statSync(path);
    if (stat.isDirectory()) collectJsonFiles(path, predicate, acc);
    else if (predicate(path)) acc.push(path);
  }
  return acc;
}

function parseTail() {
  const path = join(evidenceDir, 'production-tail.log');
  const text = existsSync(path) ? readFileSync(path, 'utf8') : '';
  const versionIds = [...text.matchAll(/"scriptVersion"\s*:\s*\{\s*"id"\s*:\s*"([^"]+)"/g)].map(match => match[1]);
  const outcomes = [...text.matchAll(/"outcome"\s*:\s*"([^"]+)"/g)].map(match => match[1]);
  return {
    exact_events: versionIds.filter(id => id === candidateVersionId).length,
    observed_version_ids: [...new Set(versionIds)],
    non_ok_outcomes: outcomes.filter(outcome => outcome !== 'ok')
  };
}

async function finalVerification() {
  const contract = await import(new URL(`file://${join(sourceRoot, 'scripts', 'required-city-platform-assets.mjs')}`).href);
  const expectedManifest = loadExpectedManifest();
  const result = await singleProductionRound(contract, expectedManifest, 9999);
  if (!result.record.pass) throw new Error(`final_production_round_failed:${JSON.stringify(result.record)}`);
  const tail = parseTail();
  if (tail.exact_events < 1 || tail.non_ok_outcomes.length > 0 || tail.observed_version_ids.some(id => id !== candidateVersionId)) throw new Error(`production_tail_failed:${JSON.stringify(tail)}`);
  const consoleFiles = collectJsonFiles(evidenceDir, path => path.endsWith('-console.json'));
  const pageErrorFiles = collectJsonFiles(evidenceDir, path => path.endsWith('-pageerrors.json'));
  const requestFiles = collectJsonFiles(evidenceDir, path => path.endsWith('-requests.json'));
  let consoleErrors = 0;
  let pageErrors = 0;
  let directNominatim = 0;
  for (const file of consoleFiles) {
    const rows = JSON.parse(readFileSync(file, 'utf8'));
    if (Array.isArray(rows)) consoleErrors += rows.filter(row => row?.type === 'error').length;
  }
  for (const file of pageErrorFiles) {
    const rows = JSON.parse(readFileSync(file, 'utf8'));
    if (Array.isArray(rows)) pageErrors += rows.length;
  }
  for (const file of requestFiles) {
    const rows = JSON.parse(readFileSync(file, 'utf8'));
    if (Array.isArray(rows)) directNominatim += rows.filter(row => String(row?.url || '').includes('nominatim.openstreetmap.org')).length;
  }
  if (consoleErrors || pageErrors || directNominatim) throw new Error(`browser_evidence_failed:${JSON.stringify({ consoleErrors, pageErrors, directNominatim })}`);
  const proof = JSON.parse(readFileSync(join(evidenceDir, 'production-convergence-proof.json'), 'utf8'));
  const finalState = {
    result: 'PASS',
    source_sha: expectedHead,
    source_short_sha: expectedShort,
    production_version_id: candidateVersionId,
    production_deployment_id: result.record.deployment_id,
    production_build: result.record.health?.build_hash,
    stable_previous_version_id: stableVersionId,
    stable_previous_traffic: 0,
    production_traffic: 100,
    convergence_rounds: proof.consecutive,
    convergence_duration_ms: proof.stable_window_ms,
    required_assets: 13,
    body_hash_pass: result.record.body_hash_pass,
    schema_pass: result.record.schema_pass,
    browser_console_errors: consoleErrors,
    browser_pageerrors: pageErrors,
    direct_nominatim: directNominatim,
    tail,
    rollback_executed_for_second_attempt: false,
    verified_at: new Date().toISOString()
  };
  writeJson('final-production-state.json', finalState);
  console.log(JSON.stringify(finalState, null, 2));
}

async function verifyRollback() {
  const deployments = await cloudflare('/deployments');
  const deployment = inspectDeployment(deployments, 100, 0);
  if (!deployment.valid) throw new Error('rollback_deployment_contract_failed');
  const rounds = [];
  for (let round = 1; round <= 3; round += 1) {
    const health = await normalHealth(`second_attempt_rollback_${round}`);
    const pass = health.body?.ok === true && health.body?.version === expectedProductionVersion && health.body?.build_hash === expectedStableBuild;
    rounds.push({ round, pass, body: health.body, timestamp: new Date().toISOString() });
    if (!pass) throw new Error(`rollback_health_failed:${round}`);
    await new Promise(resolvePromise => setTimeout(resolvePromise, 1000));
  }
  writeJson('rollback-verification.json', { deployment_id: deployment.active.id, stable_version_id: stableVersionId, stable_traffic: 100, candidate_version_id: candidateVersionId, candidate_traffic: 0, health_rounds: rounds, verified_at: new Date().toISOString() });
  appendGithubEnv('SECOND_ATTEMPT_ROLLBACK_EXECUTED', '1');
}

const mode = process.argv[2];
try {
  if (mode === 'preflight') await preflight();
  else if (mode === 'converge') await converge();
  else if (mode === 'final') await finalVerification();
  else if (mode === 'verify-rollback') await verifyRollback();
  else throw new Error(`unknown_mode:${mode}`);
} catch (error) {
  console.error(error?.stack || error);
  process.exit(1);
}
